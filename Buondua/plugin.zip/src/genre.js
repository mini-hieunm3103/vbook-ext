function execute() {
    return Response.success([
        {title: "buon dua", input: "https://buondua.com/hot/", script: "gen.js"},
    ]);
}